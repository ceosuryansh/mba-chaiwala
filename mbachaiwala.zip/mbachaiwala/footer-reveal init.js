$('.js-fixed-footer').footerReveal({ 
	shadow: false,
	zIndex : 1
});